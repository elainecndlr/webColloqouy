Rails.application.routes.draw do
  get 'users/new'

	get 'forums' => 'forums#index'
	get 'forums' => 'forums#add'
	get '/forums/new' => 'forums#new'
	get '/forums/:id' => 'forums#show'
	get '/forums' => 'forums#form'
	post '/forums' => 'forums#create'
	get '/forums/:id/edit' => 'phones#edit'
	patch '/forums/:id/edit' => 'phones#update'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
