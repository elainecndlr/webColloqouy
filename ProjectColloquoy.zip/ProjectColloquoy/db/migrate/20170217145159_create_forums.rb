class CreateForums < ActiveRecord::Migration[5.0]
  def change
    create_table :forums do |t|
      t.string :topic
      t.text :description
      t.boolean :vote
      t.datetime :time_posted
      t.string :user

      t.timestamps
    end
  end
end
