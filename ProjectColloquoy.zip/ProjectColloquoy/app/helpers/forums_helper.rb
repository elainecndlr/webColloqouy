module ForumsHelper
end
