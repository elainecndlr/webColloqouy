class ForumsController < ApplicationController
	def index
		@forums = Forum.all
	end

	
	def new 
		@forums = Forum.new()
	end
	
	def create
	    @forums = Forum.new()
	    @forums.topic = params[:forum][:topic]
	    @forums.description = params[:forum][:description]
	    @forums.vote = params[:forum][:vote]
	    @forums.time_posted = params[:forum][:time_posted]
	    @forums.user = params[:forum][:user]
	    @forums.save
	    redirect_to "/forums/#{@forums.id}"
	end

	def edit
	    @forum = Phone.find(params[:id])
	end

	def update
		@forums = Phone.find(params[:id])
		@forums.topic = params[:forum][:topic]
	    @forums.description = params[:forum][:description]
	    @forums.vote = params[:forum][:vote]
	    @forums.time_posted = params[:forum][:time_posted]
	    @forums.user = params[:forum][:user]
		@forums.update(h)
	end
end
